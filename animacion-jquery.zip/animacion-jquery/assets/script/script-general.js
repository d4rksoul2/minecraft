function moverPersonaje(id, direccion) {
    const $personaje1 = $('#' + id);
    const paso = 20; // numero de pixeles que se movera  mi abejaa

    //div  posicitionrelative
    if (!$personaje1.css('position') || $personaje1.css('position') === 'static') {
        $personaje1.css('position', 'relative');
    }

    // Obtener posición actual
    let top = parseInt($personaje1.css('top')) || 0;
    let left = parseInt($personaje1.css('left')) || 0;

    // Cambiar posición según la dirección
 switch (direccion) {
    case 'izquierda':
            left -= paso;
            break;
     case 'derecha':
            left += paso;
            break;
    case 'arriba':
            top -= paso;
            break;
    case 'abajo':
            top += paso;
            break;
    }

    // aplicanueva posición
    $personaje1.css({
        top: top + 'px',
        left: left + 'px'
    });
}

// personaje 2
function desaparecerPersonaje(id) {
    $('#' + id).fadeToggle(100); 
}

//personaje 3 usando canvas-confetti, la otra libreria
function explotarPersonaje(id) {
    const $personaje3 = $('#' + id);

 // Obtener posición del personaje para lanzar confetti ahí
const offset = $personaje3.offset();
const width = $personaje3.outerWidth();
const height = $personaje3.outerHeight();


$personaje3.hide();
//configuracion de la librería canvas-confetti
//lanzaa el confetti en la posición del personajee
 confetti({
 particleCount: 100, // cantidad de partículas que se van a lanzar
spread: 70, // angulo de dispersion de las particulas cuanto mas grande es el numero mas se dispersan
origin: {//Define el punto de origen desde donde salen las particulas
 x: (offset.left + width / 2)/ $(window).width(),
 y: (offset.top + height / 2)/ $(window).height()
 }
}
);

setTimeout(() => {
$personaje3.show();
}, 3000);
}

//personaje 4 
function acariciarPersonaje(id) {
    
const audio = document.getElementById('audio-acariciar');
audio.currentTime = 0; 
audio.play();



 

}
